public class Statistics implements Observer{
  @Override
  public void update(int goals, int yellowCard, int redCard, int hitWoodwork, int normalShoots) {
    
  }
  public void display(){
    
  }
}